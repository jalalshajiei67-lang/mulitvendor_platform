// src/index.ts
import { TableCell } from "@tiptap/extension-table";
import { TableCell as TableCell2 } from "@tiptap/extension-table";
var index_default = TableCell;
export {
  TableCell2 as TableCell,
  index_default as default
};
//# sourceMappingURL=index.js.map