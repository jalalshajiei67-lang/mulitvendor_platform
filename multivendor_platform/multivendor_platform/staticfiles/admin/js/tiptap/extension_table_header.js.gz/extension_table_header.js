// src/index.ts
import { TableHeader } from "@tiptap/extension-table";
import { TableHeader as TableHeader2 } from "@tiptap/extension-table";
var index_default = TableHeader;
export {
  TableHeader2 as TableHeader,
  index_default as default
};
//# sourceMappingURL=index.js.map