// src/index.ts
import { TableRow } from "@tiptap/extension-table";
import { TableRow as TableRow2 } from "@tiptap/extension-table";
var index_default = TableRow;
export {
  TableRow2 as TableRow,
  index_default as default
};
//# sourceMappingURL=index.js.map