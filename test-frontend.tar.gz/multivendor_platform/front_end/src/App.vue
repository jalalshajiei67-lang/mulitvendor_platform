<!-- src/App.vue -->
<template>
  <v-app>
    <!-- Persistent Header with Large Mobile-Compatible Search Bar -->
    <AppHeader v-if="!isAdminDashboard" />

    <!-- Main Content -->
    <v-main class="bg-background" :class="{ 'mobile-main': isMobile && !isAdminDashboard }">
      <router-view />
    </v-main>

    <!-- Footer with Material Design 3 (Desktop Only) -->
    <v-footer 
      v-if="!isAdminDashboard"
      color="primary" 
      class="text-center d-none d-md-block" 
      elevation="8"
    >
      <v-container>
        <v-row>
          <v-col cols="12" sm="6" md="4">
            <h3 class="text-subtitle-1 text-sm-h6 mb-2">درباره ما</h3>
            <p class="text-caption text-sm-body-2">ایندکسو</p>
          </v-col>
          <v-col cols="12" sm="6" md="4">
            <h3 class="text-subtitle-1 text-sm-h6 mb-2">لینک‌های سریع</h3>
            <div class="d-flex flex-column align-center">
              <router-link to="/departments" class="text-white text-decoration-none mb-1 hover-link">محصولات</router-link>
              <router-link to="/suppliers" class="text-white text-decoration-none mb-1 hover-link">تامین‌کنندگان</router-link>
              <router-link to="/blog" class="text-white text-decoration-none mb-1 hover-link">وبلاگ</router-link>
              <router-link to="/contact-us" class="text-white text-decoration-none mb-1 hover-link">تماس با ما</router-link>
              <router-link to="/sitemap" class="text-white text-decoration-none mb-1 hover-link">نقشه سایت</router-link>
            </div>
          </v-col>
          <v-col cols="12" md="4">
            <h3 class="text-subtitle-1 text-sm-h6 mb-2">تماس با ما</h3>
            <p class="text-caption text-sm-body-2 mb-1">ایمیل: info@example.com</p>
            <p class="text-caption text-sm-body-2">تلفن02188311001 </p>
          </v-col>
        </v-row>
        <v-divider class="my-3 my-sm-4"></v-divider>
        <p class="text-caption text-sm-body-2">&copy; {{ new Date().getFullYear() }} پلتفرم چند فروشنده. تمامی حقوق محفوظ است.</p>
      </v-container>
    </v-footer>

    <!-- Bottom Navigation (Mobile/Tablet Only - replaces drawer) -->
    <BottomNavigation v-if="isMobile && !isAdminDashboard" />
  </v-app>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useDisplay } from 'vuetify'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import AppHeader from '@/components/layout/AppHeader.vue'
import BottomNavigation from '@/components/layout/BottomNavigation.vue'

const { mdAndDown } = useDisplay()
const route = useRoute()
const authStore = useAuthStore()

// Check if mobile/tablet (< 960px / md breakpoint)
const isMobile = computed(() => mdAndDown.value)

// Admin-related routes that should use admin layout
const adminRoutes = [
  '/admin/dashboard',
  '/admin/dashboard/products/new',
  '/admin/dashboard/blog/new',
  '/products/new',
  '/blog/new'
]

// Check if current route is an admin route (exact match or pattern match for edit routes)
const isAdminRoute = computed(() => {
  const path = route.path
  // Exact matches
  if (adminRoutes.includes(path)) {
    return authStore.isAdmin
  }
  // Pattern matches for edit routes (both admin nested and regular routes)
  if (authStore.isAdmin) {
    if (path.match(/^\/admin\/dashboard\/products\/\d+\/edit$/)) return true
    if (path.match(/^\/admin\/dashboard\/blog\/[^/]+\/edit$/)) return true
    if (path.match(/^\/products\/\d+\/edit$/)) return true
    if (path.match(/^\/blog\/[^/]+\/edit$/)) return true
  }
  return false
})

// Hide header and bottom nav on admin dashboard and admin-managed routes
const isAdminDashboard = computed(() => isAdminRoute.value)

onMounted(() => {
  authStore.initializeAuth()
})
</script>

<style>
/* Global styles for Vuetify Material Design 3 */
.text-white {
  color: white !important;
}

.text-decoration-none {
  text-decoration: none !important;
}

/* Hover effect for footer links */
.hover-link {
  transition: opacity 0.2s ease-in-out;
}

.hover-link:hover {
  opacity: 0.8;
}

/* Background color helper */
.bg-background {
  background-color: rgb(var(--v-theme-background)) !important;
}

/* Mobile main content padding for bottom navigation */
.mobile-main {
  padding-bottom: 80px !important; /* Space for bottom navigation */
}

/* RTL support */
[dir="rtl"] {
  direction: rtl;
  text-align: right;
}
</style>
