<!-- src/views/DepartmentDetail.vue -->
<template>
  <div class="department-detail" dir="rtl">
    <Breadcrumb :items="breadcrumbItems" />

    <!-- Loading State -->
    <div v-if="loading" class="loading-state">
      <div class="spinner"></div>
      <p>در حال بارگذاری...</p>
    </div>

    <!-- Error State -->
    <div v-else-if="error" class="error-state">
      <i class="fas fa-exclamation-triangle"></i>
      <p>{{ error }}</p>
      <button @click="fetchDepartmentData" class="retry-btn">دوباره تلاش کنید</button>
    </div>

    <!-- Department Content -->
    <div v-else-if="department">
      <!-- Department Header -->
      <div class="department-header">
        <div class="department-image">
          <img 
            v-if="department.image || department.image_url" 
            :src="formatImageUrl(department)" 
            :alt="department.name"
          />
          <div v-else class="placeholder-image">
            <i class="fas fa-folder"></i>
          </div>
        </div>
        <div class="department-info">
          <h1>{{ department.name }}</h1>
        </div>
      </div>

      <!-- Categories Section -->
      <div class="categories-section">
        <h2>دسته‌بندی‌های این بخش</h2>

        <!-- Categories Grid -->
        <div v-if="paginatedCategories.length > 0" class="items-grid">
          <div 
            v-for="category in paginatedCategories" 
            :key="category.id" 
            class="item-card"
            @click="goToCategoryDetail(category.slug)"
          >
            <div class="circular-image">
              <img 
                v-if="category.image || category.image_url" 
                :src="formatImageUrl(category)" 
                :alt="category.name"
              />
              <div v-else class="placeholder-image">
                <i class="fas fa-tag"></i>
              </div>
            </div>
            <h3 class="item-title">{{ category.name }}</h3>
          </div>
        </div>

        <!-- Empty State -->
        <div v-else class="empty-state">
          <i class="fas fa-tag"></i>
          <h3>دسته‌بندی وجود ندارد</h3>
          <p>هیچ دسته‌بندی در این بخش وجود ندارد.</p>
        </div>

        <!-- Pagination -->
        <div class="pagination" v-if="totalPages > 1">
          <button 
            @click="previousPage" 
            :disabled="currentPage === 1" 
            class="btn btn-secondary"
          >
            قبلی
          </button>
          <span>صفحه {{ currentPage }} از {{ totalPages }}</span>
          <button 
            @click="nextPage" 
            :disabled="currentPage === totalPages" 
            class="btn btn-secondary"
          >
            بعدی
          </button>
        </div>
      </div>

      <!-- Department Description Section -->
      <div v-if="department.description" class="department-description-section">
        <div class="description-content">
          <h2>درباره این بخش</h2>
          <div class="description rich-text-content" v-html="department.description"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useHead } from '@unhead/vue'
import api from '@/services/api'
import Breadcrumb from '@/components/Breadcrumb.vue'
import { formatImageUrl } from '@/utils/imageUtils'
import { prepareSchemaScripts, generateBreadcrumbSchema } from '@/composables/useSchema'

export default {
  name: 'DepartmentDetail',
  components: {
    Breadcrumb
  },
  setup() {
    const route = useRoute()
    const router = useRouter()
    const department = ref(null)
    const categories = ref([])
    const loading = ref(false)
    const error = ref(null)
    const searchQuery = ref('')
    const currentPage = ref(1)
    const itemsPerPage = 12

    const breadcrumbItems = computed(() => [
      { text: 'خانه', to: '/' },
      { text: 'بخش‌ها', to: '/departments' },
      { text: department.value?.name || 'بخش', to: `/departments/${route.params.slug}` }
    ])

    // Setup useHead at the top with reactive data
    useHead(() => {
      if (!department.value) {
        return {
          title: 'بخش',
          meta: []
        }
      }

      const baseUrl = typeof window !== 'undefined' && window.location?.origin
        ? window.location.origin
        : import.meta.env.VITE_SITE_URL || ''

      const schemas = []

      // Use schema_markup from database if available
      if (department.value.schema_markup) {
        try {
          const parsedSchema = typeof department.value.schema_markup === 'string'
            ? JSON.parse(department.value.schema_markup)
            : department.value.schema_markup
          
          if (Array.isArray(parsedSchema)) {
            schemas.push(...parsedSchema)
          } else {
            schemas.push(parsedSchema)
          }

          // Add BreadcrumbList schema only if schema_markup exists
          if (breadcrumbItems.value.length > 0 && baseUrl) {
            const breadcrumbSchema = generateBreadcrumbSchema(
              breadcrumbItems.value.map(item => ({
                name: item.text,
                url: item.to ? `${baseUrl}${item.to}` : undefined
              })),
              baseUrl
            )
            if (breadcrumbSchema) {
              schemas.push(breadcrumbSchema)
            }
          }
        } catch (error) {
          console.warn('Error parsing schema_markup:', error)
        }
      }

      // Prepare script tags for schemas
      const scriptTags = schemas.length > 0 ? prepareSchemaScripts(schemas) : []

      return {
        title: department.value.meta_title || department.value.name,
        meta: [
          {
            name: 'description',
            content: department.value.meta_description || (department.value.description ? department.value.description.substring(0, 160) : '')
          }
        ],
        ...(scriptTags.length > 0 && { script: scriptTags })
      }
    })

    const fetchDepartmentData = async () => {
      loading.value = true
      error.value = null
      try {
        // Fetch department by slug
        console.log('Fetching department with slug:', route.params.slug)
        const deptResponse = await api.getDepartmentBySlug(route.params.slug)
        console.log('Department response:', deptResponse)
        console.log('Department response data:', deptResponse.data)
        
        // Handle different response structures
        let deptData = deptResponse.data
        if (deptResponse.data.results) {
          deptData = deptResponse.data.results
        }
        
        if (deptData && (Array.isArray(deptData) ? deptData.length > 0 : deptData.id)) {
          department.value = Array.isArray(deptData) ? deptData[0] : deptData
          console.log('Department found:', department.value)
          
          // Fetch categories filtered by department ID using backend API
          const catResponse = await api.getCategories({ department: department.value.id })
          console.log('Categories response for department:', catResponse)
          console.log('Categories data:', catResponse.data)
          
          let categoriesData = catResponse.data
          if (catResponse.data.results) {
            categoriesData = catResponse.data.results
          }
          
          console.log('Filtered categories for this department:', categoriesData)
          
          // Assign categories (already filtered by backend)
          if (Array.isArray(categoriesData)) {
            categories.value = categoriesData
          } else {
            categories.value = []
          }
          
          console.log('Number of categories:', categories.value.length)
        } else {
          error.value = 'بخش یافت نشد'
          console.log('Department not found')
        }
      } catch (err) {
        error.value = 'بارگذاری اطلاعات با خطا مواجه شد. لطفاً دوباره تلاش کنید.'
        console.error('Error fetching department data:', err)
        console.error('Error details:', err.response)
      } finally {
        loading.value = false
      }
    }

    const filteredCategories = computed(() => {
      if (!searchQuery.value) {
        return categories.value
      }
      const query = searchQuery.value.toLowerCase()
      return categories.value.filter(cat => 
        cat.name.toLowerCase().includes(query) ||
        (cat.description && cat.description.toLowerCase().includes(query))
      )
    })

    const totalPages = computed(() => {
      return Math.ceil(filteredCategories.value.length / itemsPerPage)
    })

    const paginatedCategories = computed(() => {
      const start = (currentPage.value - 1) * itemsPerPage
      const end = start + itemsPerPage
      return filteredCategories.value.slice(start, end)
    })

    const handleSearch = () => {
      currentPage.value = 1
    }

    const nextPage = () => {
      if (currentPage.value < totalPages.value) {
        currentPage.value++
        window.scrollTo({ top: 0, behavior: 'smooth' })
      }
    }

    const previousPage = () => {
      if (currentPage.value > 1) {
        currentPage.value--
        window.scrollTo({ top: 0, behavior: 'smooth' })
      }
    }

    const goToCategoryDetail = (slug) => {
      router.push({ name: 'CategoryDetail', params: { slug } })
    }

    watch(() => route.params.slug, () => {
      if (route.name === 'DepartmentDetail') {
        fetchDepartmentData()
      }
    })

    onMounted(() => {
      fetchDepartmentData()
    })

    return {
      department,
      categories,
      filteredCategories,
      paginatedCategories,
      loading,
      error,
      currentPage,
      totalPages,
      breadcrumbItems,
      nextPage,
      previousPage,
      goToCategoryDetail,
      fetchDepartmentData,
      formatImageUrl
    }
  }
}
</script>

<style scoped>
.department-detail {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
}

/* Department Header */
.department-header {
  display: flex;
  align-items: center;
  gap: 30px;
  margin-bottom: 40px;
  padding: 30px;
  background: linear-gradient(135deg, #1565C0 0%, #0277BD 100%);
  border-radius: 15px;
  color: white;
}

.department-image {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  background: white;
}

.department-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.department-image .placeholder-image {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  font-size: 4rem;
}

.department-info {
  flex: 1;
}

.department-info h1 {
  font-size: 2.5rem;
  margin: 0;
}

/* Department Description Section */
.department-description-section {
  margin-top: 60px;
  padding: 40px;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
}

.description-content h2 {
  font-size: 1.8rem;
  color: #212121;
  margin-bottom: 20px;
  text-align: center;
}

.description-content .description {
  font-size: 1.1rem;
  line-height: 1.8;
  color: #555;
  text-align: justify;
  max-width: 900px;
  margin: 0 auto;
}

/* Rich text content styling for HTML descriptions */
.rich-text-content {
  text-align: right;
  direction: rtl;
}

.rich-text-content :deep(p) {
  margin-bottom: 1.2em;
  line-height: 1.8;
  text-align: justify;
}

.rich-text-content :deep(h1),
.rich-text-content :deep(h2),
.rich-text-content :deep(h3),
.rich-text-content :deep(h4),
.rich-text-content :deep(h5),
.rich-text-content :deep(h6) {
  margin-top: 1.5em;
  margin-bottom: 0.8em;
  font-weight: 700;
  line-height: 1.4;
  color: #212121;
}

.rich-text-content :deep(h1) {
  font-size: 2em;
}

.rich-text-content :deep(h2) {
  font-size: 1.75em;
}

.rich-text-content :deep(h3) {
  font-size: 1.5em;
}

.rich-text-content :deep(ul),
.rich-text-content :deep(ol) {
  margin: 1em 0;
  padding-right: 2em;
  line-height: 1.8;
}

.rich-text-content :deep(li) {
  margin-bottom: 0.5em;
}

.rich-text-content :deep(a) {
  color: #1565C0;
  text-decoration: underline;
  transition: color 0.3s ease;
}

.rich-text-content :deep(a:hover) {
  color: #0D47A1;
}

.rich-text-content :deep(img) {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
  margin: 1.5em 0;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.rich-text-content :deep(blockquote) {
  border-right: 4px solid #1565C0;
  padding-right: 1.5em;
  margin: 1.5em 0;
  font-style: italic;
  color: #666;
  background-color: #f8f9fa;
  padding: 1em 1.5em;
  border-radius: 4px;
}

.rich-text-content :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 1.5em 0;
}

.rich-text-content :deep(table th),
.rich-text-content :deep(table td) {
  padding: 0.75em;
  border: 1px solid #ddd;
  text-align: right;
}

.rich-text-content :deep(table th) {
  background-color: #f5f7fa;
  font-weight: 700;
  color: #333;
}

.rich-text-content :deep(strong),
.rich-text-content :deep(b) {
  font-weight: 700;
  color: #212121;
}

.rich-text-content :deep(em),
.rich-text-content :deep(i) {
  font-style: italic;
}

.rich-text-content :deep(code) {
  background-color: #f5f7fa;
  padding: 0.2em 0.4em;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
  color: #e83e8c;
}

.rich-text-content :deep(pre) {
  background-color: #f5f7fa;
  padding: 1em;
  border-radius: 8px;
  overflow-x: auto;
  margin: 1.5em 0;
  border: 1px solid #e0e0e0;
}

.rich-text-content :deep(pre code) {
  background-color: transparent;
  padding: 0;
  color: #212121;
}

/* Categories Section */
.categories-section {
  margin-top: 40px;
}

.categories-section h2 {
  font-size: 2rem;
  color: #212121;
  margin-bottom: 30px;
  text-align: center;
}

/* Grid Layout */
.items-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 30px;
  margin-bottom: 40px;
}

.item-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  transition: transform 0.3s ease;
  padding: 20px;
  border-radius: 10px;
}

.item-card:hover {
  transform: translateY(-5px);
}

/* Circular Image */
.circular-image {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  overflow: hidden;
  margin-bottom: 20px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.3s ease;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
}

.item-card:hover .circular-image {
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
}

.circular-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.circular-image .placeholder-image {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #FF6F00 0%, #FF8F00 100%);
  color: white;
  font-size: 3rem;
}

.item-title {
  font-size: 1.1rem;
  color: #212121;
  text-align: center;
  margin: 0;
  font-weight: 600;
  transition: color 0.3s ease;
  width: 100%;
  padding: 8px 0;
}

.item-card:hover .item-title {
  color: #1565C0;
}

/* Loading State */
.loading-state {
  text-align: center;
  padding: 60px 20px;
}

.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #1565C0;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 1s linear infinite;
  margin: 0 auto 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Error State */
.error-state {
  text-align: center;
  padding: 60px 20px;
  color: #d32f2f;
}

.error-state i {
  font-size: 3rem;
  margin-bottom: 20px;
}

.retry-btn {
  margin-top: 20px;
  padding: 10px 30px;
  background: #1565C0;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1rem;
}

.retry-btn:hover {
  background: #0D47A1;
}

/* Empty State */
.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #666;
}

.empty-state i {
  font-size: 4rem;
  margin-bottom: 20px;
  color: #ccc;
}

.empty-state h3 {
  font-size: 1.5rem;
  margin-bottom: 10px;
  color: #212121;
}

/* Pagination */
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
  margin-top: 40px;
}

.pagination button {
  padding: 10px 20px;
  background: #1565C0;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s ease;
}

.pagination button:hover:not(:disabled) {
  background: #0D47A1;
}

.pagination button:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.pagination span {
  font-size: 1rem;
  color: #666;
}

/* Responsive Design */
@media (max-width: 768px) {
  .department-header {
    flex-direction: column;
    text-align: center;
  }

  .department-info h1 {
    font-size: 1.8rem;
  }

  .items-grid {
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 20px;
  }

  .circular-image {
    width: 120px;
    height: 120px;
  }

  .department-image {
    width: 120px;
    height: 120px;
  }

  .department-description-section {
    padding: 30px 20px;
    margin-top: 40px;
  }

  .description-content h2 {
    font-size: 1.5rem;
  }

  .description-content .description {
    font-size: 1rem;
  }
}
</style>