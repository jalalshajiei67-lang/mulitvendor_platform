<!-- src/views/SubcategoryDetail.vue -->
<template>
  <div class="subcategory-detail" dir="rtl">
    <Breadcrumb :items="breadcrumbItems" />

    <!-- Loading State -->
    <div v-if="loading" class="loading-state">
      <div class="spinner"></div>
      <p>در حال بارگذاری...</p>
    </div>

    <!-- Error State -->
    <div v-else-if="error" class="error-state">
      <i class="fas fa-exclamation-triangle"></i>
      <p>{{ error }}</p>
      <button @click="fetchSubcategoryData" class="retry-btn">دوباره تلاش کنید</button>
    </div>

    <!-- Subcategory Content -->
    <div v-else-if="subcategory">
      <!-- Subcategory Header -->
      <div class="subcategory-header">
        <div class="subcategory-image">
          <img 
            v-if="subcategory.image || subcategory.image_url" 
            :src="formatImageUrl(subcategory)" 
            :alt="subcategory.name"
          />
          <div v-else class="placeholder-image">
            <i class="fas fa-layer-group"></i>
          </div>
        </div>
        <div class="subcategory-info">
          <h1>{{ subcategory.name }}</h1>
        </div>
      </div>

      <!-- Products Section -->
      <div class="products-section">
        <h2>محصولات این زیردسته</h2>

        <!-- Products Grid -->
        <div v-if="paginatedProducts.length > 0" class="items-grid">
          <div 
            v-for="product in paginatedProducts" 
            :key="product.id" 
            class="item-card"
            @click="goToProductDetail(product.slug || product.id)"
          >
            <div class="circular-image">
              <img 
                v-if="getProductImage(product)" 
                :src="getProductImage(product)" 
                :alt="product.name"
              />
              <div v-else class="placeholder-image">
                <i class="fas fa-box"></i>
              </div>
            </div>
            <h3 class="item-title">{{ product.name }}</h3>
            <p class="item-price">${{ product.price }}</p>
          </div>
        </div>

        <!-- Empty State -->
        <div v-else class="empty-state">
          <i class="fas fa-box-open"></i>
          <h3>محصولی وجود ندارد</h3>
          <p>هیچ محصولی در این زیردسته وجود ندارد.</p>
        </div>

        <!-- Pagination -->
        <div class="pagination" v-if="totalPages > 1">
          <button 
            @click="previousPage" 
            :disabled="currentPage === 1" 
            class="btn btn-secondary"
          >
            قبلی
          </button>
          <span>صفحه {{ currentPage }} از {{ totalPages }}</span>
          <button 
            @click="nextPage" 
            :disabled="currentPage === totalPages" 
            class="btn btn-secondary"
          >
            بعدی
          </button>
        </div>

        <!-- Description Section -->
        <div class="department-description-section" v-if="subcategory.description">
          <div class="description-content">
            <h2>درباره این زیردسته</h2>
            <p class="description">{{ subcategory.description }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useHead } from '@unhead/vue'
import api from '@/services/api'
import Breadcrumb from '@/components/Breadcrumb.vue'
import { formatImageUrl } from '@/utils/imageUtils'
import { prepareSchemaScripts, generateBreadcrumbSchema } from '@/composables/useSchema'

export default {
  name: 'SubcategoryDetail',
  components: {
    Breadcrumb
  },
  setup() {
    const route = useRoute()
    const router = useRouter()
    const subcategory = ref(null)
    const products = ref([])
    const loading = ref(false)
    const error = ref(null)
    const currentPage = ref(1)
    const itemsPerPage = 12

    const breadcrumbItems = computed(() => {
      const items = [
        { text: 'خانه', to: '/' },
        { text: 'بخش‌ها', to: '/departments' }
      ]
      
      // Add department if available
      if (subcategory.value?.departments && subcategory.value.departments.length > 0) {
        const dept = subcategory.value.departments[0]
        items.push({ text: dept.name, to: `/departments/${dept.slug}` })
      }
      
      // Add category if available
      if (subcategory.value?.categories && subcategory.value.categories.length > 0) {
        const cat = subcategory.value.categories[0]
        items.push({ text: cat.name, to: `/categories/${cat.slug}` })
      }
      
      items.push({ text: subcategory.value?.name || 'زیردسته', to: `/subcategories/${route.params.slug}` })
      
      return items
    })

    // Setup useHead at the top with reactive data
    useHead(() => {
      if (!subcategory.value) {
        return {
          title: 'زیردسته',
          meta: []
        }
      }

      const baseUrl = typeof window !== 'undefined' && window.location?.origin
        ? window.location.origin
        : import.meta.env.VITE_SITE_URL || ''

      const schemas = []

      // Use schema_markup from database if available
      if (subcategory.value.schema_markup) {
        try {
          const parsedSchema = typeof subcategory.value.schema_markup === 'string'
            ? JSON.parse(subcategory.value.schema_markup)
            : subcategory.value.schema_markup
          
          if (Array.isArray(parsedSchema)) {
            schemas.push(...parsedSchema)
          } else {
            schemas.push(parsedSchema)
          }

          // Add BreadcrumbList schema only if schema_markup exists
          if (breadcrumbItems.value.length > 0 && baseUrl) {
            const breadcrumbSchema = generateBreadcrumbSchema(
              breadcrumbItems.value.map(item => ({
                name: item.text,
                url: item.to ? `${baseUrl}${item.to}` : undefined
              })),
              baseUrl
            )
            if (breadcrumbSchema) {
              schemas.push(breadcrumbSchema)
            }
          }
        } catch (error) {
          console.warn('Error parsing schema_markup:', error)
        }
      }

      // Prepare script tags for schemas
      const scriptTags = schemas.length > 0 ? prepareSchemaScripts(schemas) : []

      return {
        title: subcategory.value.meta_title || subcategory.value.name,
        meta: [
          {
            name: 'description',
            content: subcategory.value.meta_description || (subcategory.value.description ? subcategory.value.description.substring(0, 160) : '')
          }
        ],
        ...(scriptTags.length > 0 && { script: scriptTags })
      }
    })

    const fetchSubcategoryData = async () => {
      loading.value = true
      error.value = null
      try {
        // Fetch subcategory by slug
        console.log('Fetching subcategory with slug:', route.params.slug)
        const subResponse = await api.getSubcategoryBySlug(route.params.slug)
        console.log('Subcategory response:', subResponse.data)
        
        // Handle paginated or array response
        let subcategoryData = null
        if (subResponse.data && subResponse.data.results && subResponse.data.results.length > 0) {
          // Paginated response
          subcategoryData = subResponse.data.results[0]
        } else if (subResponse.data && Array.isArray(subResponse.data) && subResponse.data.length > 0) {
          // Direct array response
          subcategoryData = subResponse.data[0]
        }
        
        if (subcategoryData) {
          subcategory.value = subcategoryData
          console.log('Subcategory found:', subcategory.value)
          
          // Fetch products filtered by subcategory ID using the correct parameter name
          console.log('Fetching products for subcategory ID:', subcategory.value.id)
          const prodResponse = await api.getProducts({ subcategories: subcategory.value.id })
          console.log('Products response:', prodResponse.data)
          
          // Handle paginated response
          let productsList = []
          if (prodResponse.data && prodResponse.data.results) {
            productsList = prodResponse.data.results
          } else if (Array.isArray(prodResponse.data)) {
            productsList = prodResponse.data
          }
          
          // Filter only active products
          products.value = productsList.filter(prod => prod.is_active)
          console.log('Active products found:', products.value.length, products.value)
        } else {
          error.value = 'زیردسته یافت نشد'
          console.log('No subcategory found in response')
        }
      } catch (err) {
        error.value = 'بارگذاری اطلاعات با خطا مواجه شد. لطفاً دوباره تلاش کنید.'
        console.error('Error fetching subcategory data:', err)
        console.error('Error details:', err.response?.data)
      } finally {
        loading.value = false
      }
    }

    const getProductImage = (product) => {
      if (product.primary_image) {
        return product.primary_image
      }
      if (product.images && product.images.length > 0) {
        return product.images[0].image_url || product.images[0].image
      }
      if (product.image) {
        return product.image
      }
      return null
    }

    const totalPages = computed(() => {
      return Math.ceil(products.value.length / itemsPerPage)
    })

    const paginatedProducts = computed(() => {
      const start = (currentPage.value - 1) * itemsPerPage
      const end = start + itemsPerPage
      return products.value.slice(start, end)
    })

    const nextPage = () => {
      if (currentPage.value < totalPages.value) {
        currentPage.value++
        window.scrollTo({ top: 0, behavior: 'smooth' })
      }
    }

    const previousPage = () => {
      if (currentPage.value > 1) {
        currentPage.value--
        window.scrollTo({ top: 0, behavior: 'smooth' })
      }
    }

    const goToProductDetail = (slugOrId) => {
      if (!slugOrId) return
      router.push({ name: 'ProductDetail', params: { slug: slugOrId } })
    }

    watch(() => route.params.slug, () => {
      if (route.name === 'SubcategoryDetail') {
        fetchSubcategoryData()
      }
    })

    onMounted(() => {
      fetchSubcategoryData()
    })

    return {
      subcategory,
      products,
      paginatedProducts,
      loading,
      error,
      currentPage,
      totalPages,
      breadcrumbItems,
      nextPage,
      previousPage,
      goToProductDetail,
      getProductImage,
      fetchSubcategoryData,
      formatImageUrl
    }
  }
}
</script>

<style scoped>
.subcategory-detail {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
}

/* Subcategory Header */
.subcategory-header {
  display: flex;
  align-items: center;
  gap: 30px;
  margin-bottom: 50px;
  padding: 30px;
  background: linear-gradient(135deg, #1565C0 0%, #0277BD 100%);
  border-radius: 15px;
  color: white;
}

.subcategory-image {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  background: white;
}

.subcategory-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.subcategory-image .placeholder-image {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  font-size: 4rem;
}

.subcategory-info {
  flex: 1;
}

.subcategory-info h1 {
  font-size: 2.5rem;
  margin: 0 0 15px 0;
}

.subcategory-info .description {
  font-size: 1.2rem;
  line-height: 1.6;
  margin: 0;
  opacity: 0.95;
}

/* Products Section */
.products-section {
  margin-top: 40px;
}

.products-section h2 {
  font-size: 2rem;
  color: #212121;
  margin-bottom: 30px;
  text-align: center;
}

/* Description Section */
.department-description-section {
  margin: 50px 0;
  padding: 0;
}

.description-content {
  background: linear-gradient(135deg, #1565C0 0%, #0277BD 100%);
  padding: 40px;
  border-radius: 15px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  color: white;
  text-align: center;
  position: relative;
  overflow: hidden;
}

.description-content::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
  pointer-events: none;
}

.description-content h2 {
  font-size: 1.8rem;
  color: white;
  margin-bottom: 20px;
  font-weight: 700;
  position: relative;
  z-index: 1;
}

.description-content .description {
  font-size: 1.1rem;
  color: rgba(255, 255, 255, 0.95);
  line-height: 2;
  max-width: 900px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
}

/* Grid Layout */
.items-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 30px;
  margin-bottom: 40px;
}

.item-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  transition: transform 0.3s ease;
  padding: 20px;
  border-radius: 10px;
  background: #fff;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.item-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

/* Circular Image */
.circular-image {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  overflow: hidden;
  margin-bottom: 15px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.3s ease;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
}

.item-card:hover .circular-image {
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
}

.circular-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.circular-image .placeholder-image {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #FF6F00 0%, #FF8F00 100%);
  color: white;
  font-size: 3rem;
}

.item-title {
  font-size: 1.1rem;
  color: #212121;
  text-align: center;
  margin: 0 0 10px 0;
  font-weight: 600;
  transition: color 0.3s ease;
}

.item-price {
  font-size: 1.2rem;
  color: #FF6F00;
  font-weight: bold;
  margin: 0;
}

.item-card:hover .item-title {
  color: #1565C0;
}

/* Loading State */
.loading-state {
  text-align: center;
  padding: 60px 20px;
}

.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #1565C0;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 1s linear infinite;
  margin: 0 auto 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Error State */
.error-state {
  text-align: center;
  padding: 60px 20px;
  color: #d32f2f;
}

.error-state i {
  font-size: 3rem;
  margin-bottom: 20px;
}

.retry-btn {
  margin-top: 20px;
  padding: 10px 30px;
  background: #1565C0;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1rem;
}

.retry-btn:hover {
  background: #0D47A1;
}

/* Empty State */
.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #666;
}

.empty-state i {
  font-size: 4rem;
  margin-bottom: 20px;
  color: #ccc;
}

.empty-state h3 {
  font-size: 1.5rem;
  margin-bottom: 10px;
  color: #212121;
}

/* Pagination */
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
  margin-top: 40px;
}

.pagination button {
  padding: 10px 20px;
  background: #1565C0;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s ease;
}

.pagination button:hover:not(:disabled) {
  background: #0D47A1;
}

.pagination button:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.pagination span {
  font-size: 1rem;
  color: #666;
}

/* Responsive Design */
@media (max-width: 768px) {
  .subcategory-header {
    flex-direction: column;
    text-align: center;
  }

  .subcategory-info h1 {
    font-size: 1.8rem;
  }

  .items-grid {
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 20px;
  }

  .circular-image {
    width: 120px;
    height: 120px;
  }

  .subcategory-image {
    width: 120px;
    height: 120px;
  }

  .description-content {
    padding: 25px 20px;
  }

  .description-content h2 {
    font-size: 1.4rem;
    margin-bottom: 15px;
  }

  .description-content .description {
    font-size: 1rem;
    line-height: 1.8;
  }
}
</style>

