<template>
  <v-app>
    <NuxtLoadingIndicator color="#00c58e" />
    <NuxtPage />
  </v-app>
</template>
