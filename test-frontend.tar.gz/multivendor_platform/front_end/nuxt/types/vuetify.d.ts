// Extend Vuetify typings for Nuxt auto-imported components
declare module 'vuetify/lib/framework.mjs' {
  export * from 'vuetify'
}

export {}

